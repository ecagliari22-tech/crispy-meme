/*
  Minimal entry script for a "blank" multi-file starter.
  Keeps the experience focused and touch-friendly on mobile.
*/

const app = document.getElementById('app');
const mark = document.getElementById('blank-mark');

function handleActivate(e){
  // small ephemeral feedback: toggle a focused class briefly
  mark.classList.add('focused');
  clearTimeout(mark._t);
  mark._t = setTimeout(()=> mark.classList.remove('focused'), 220);
}

// support touch and mouse interactions
mark.addEventListener('pointerdown', handleActivate, {passive:true});
mark.addEventListener('keydown', (e)=>{
  if(e.key === 'Enter' || e.key === ' ') handleActivate(e);
});

// make the blank mark focusable for keyboard accessibility
mark.tabIndex = 0;

// expose a simple API for other modules or dev use
window.__BlankApp = {
  root: app,
  mark,
  activate: handleActivate
};